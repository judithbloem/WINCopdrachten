console.log("Opdracht W1D2-4 IF/ELSE statements");

const age = 29;
if (age => 18) console.log("je hebt toegang tot dit cafe");
else console.log("je bent te jong en hebt geen toegang tot dit cafe");

const isFemale = true;
if (isFemale) console.log("je hebt toegang tot de ladiesnight");
else console.log("de ladiesnight is alleen voor vrouwen");

//const Bob = false;
//if (Bob) console.log("je bent Bob en mag rijden");
//else console.log("je bent geen Bob en mag niet rijden");

const driverStatus = "wel alcohol";
if (driverStatus === "bob") console.log("je bent Bob en mag rijden");
else console.log("je bent geen Bob en mag niet rijden");
