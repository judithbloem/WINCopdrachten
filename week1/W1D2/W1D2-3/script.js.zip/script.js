console.log("Hallo Winc Academy studenten");
//dit is een grote som
let multiple = 1230941 * 1823794;
console.log("multiple", multiple);
let divide = 637263 / 54;
console.log("divide", divide);

/*let multiple = 1230941 * 1823794;
console.log("multiple", multiple);
let divide = 637263 / 54;
console.log("divide", divide);*/
